/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

typedef enum lightColor_t {
	lightGreen,
	lightYellow,
	// we don't record red light value because in a moving direction, there are only 2 possibilities.
} lightColor_t;

typedef enum direction_t {
	direction1,
	direction2
} direction_t;

typedef struct lightStatus_t{
	char countdown;         // number of seconds remain for current light color
	lightColor_t lightColor;// in the direction vehicles are moving, light is either green or yellow
	direction_t direction;  // direction that vehicles are moving (active direction)
} lightStatus_t;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

#define maxCountdown 10
#define yellowCountdown 3

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
RTC_HandleTypeDef hrtc;
TIM_HandleTypeDef htim4;

/* USER CODE BEGIN PV */

char daytime = 1;
lightStatus_t lightStat = {maxCountdown, lightGreen, direction1 };
char count1 = maxCountdown; // count1 is waiting time for direction1 at current light color, initialized as remain time for green light
char count2 = maxCountdown+yellowCountdown;  // count2 is waiting time for direction2, initialized as remain time for red light
     // inactive direction waiting time = active direction green light + yellow light waiting time

RTC_TimeTypeDef gTime; // variable for reading real time clock

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM4_Init(void);
static void MX_RTC_Init(void);
/* USER CODE BEGIN PFP */

void showCountdown(direction_t direct, char count) {
	// this function record remaining seconds into count1 and count2, in order for TIM4_IRQHandler to get value and proceed led7seg

	if (direct == direction1)
		count1 = count;
	if (direct == direction2)
		count2 = count;
}

void led(direction_t direct, char lightNumber, char onOff) {
	// description:
	// lightNumber = 1  red led vehicle
	// lightNumber = 2  yellow led vehicle
	// lightNumber = 3  green led vehicle
    // onOff = 1 turn on led
	// onOff = 0 turn off led

	if (direct == direction1)  {
		if (lightNumber == 1)
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, onOff); // PB15 red light direction1
		if (lightNumber == 2)
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14, onOff); // PC14 yellow light direction1
		if (lightNumber == 3)
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_15, onOff); // PC15 green light direction1
	}
	if (direct == direction2)  {
		if (lightNumber == 1)
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, onOff); // PB12 red light direction2
		if (lightNumber == 2)
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, onOff); // PB13 yellow light direction2
		if (lightNumber == 3)
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, onOff); // PB14 green light direction2
	}
}

void toggleYellowLight(void) {
	// this function is for the night time mode (after 23:00)

	HAL_GPIO_TogglePin (GPIOB, GPIO_PIN_13);
	HAL_GPIO_TogglePin (GPIOC, GPIO_PIN_14);
}

void proceedLight(lightStatus_t* lightStatus) {

	// for active direction = lightStatus->direction (direction vehicles are moving)
	showCountdown(lightStatus->direction,lightStatus->countdown);
	if (lightStatus->lightColor == lightGreen) {
		led(lightStatus->direction, 1, 0);
		led(lightStatus->direction, 2, 0);
		led(lightStatus->direction, 3, 1);  // turn on green led
	}
	if (lightStatus->lightColor == lightYellow) {
		led(lightStatus->direction, 1, 0);
		led(lightStatus->direction, 2, 1);
		led(lightStatus->direction, 3, 0);  // turn on yellow led
	}

	// for inactive direction (direction vehicles are stopping)
	direction_t inactiveDirection;

	// define inactive direction = !direction
	if (lightStatus->direction == direction1) inactiveDirection=direction2;
	else inactiveDirection=direction1;

	if (lightStatus->lightColor == lightGreen) {
		showCountdown(inactiveDirection,lightStatus->countdown + yellowCountdown ); // waiting time = remain seconds of green+yellow in active direction
		led(inactiveDirection, 1, 1);
		led(inactiveDirection, 2, 0);
		led(inactiveDirection, 3, 0);
	}
	if (lightStatus->lightColor == lightYellow) {
		showCountdown(inactiveDirection,lightStatus->countdown ); // waiting time = remain seconds of yellow in active direction
		led(inactiveDirection, 1, 1);
		led(inactiveDirection, 2, 0);
		led(inactiveDirection, 3, 0);
	}
}


/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM4_Init();
  MX_RTC_Init();
  /* USER CODE BEGIN 2 */

  __HAL_RCC_TIM4_CLK_ENABLE();
  HAL_TIM_Base_Start_IT(&htim4); // enable interrupt for timer4 to handle led7seg (in file stm32f1xx_it.c )

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  HAL_RTC_GetTime(&hrtc, &gTime, RTC_FORMAT_BIN); // get value of real time clock
	  if ((gTime.Hours == 23) && (gTime.Minutes == 0) )  {  // night time mode from 23:00
		 daytime = 0;

		 // turn off all red and green lights
		 led(direction1, 1, 0);
		 led(direction1, 3, 0);
		 led(direction2, 1, 0);
		 led(direction2, 3, 0);

		 // turn off led7seg
		  GPIOA->ODR  =  (GPIOA->ODR & (~(0b1111111<<1)));  // PA1~PA7
		  GPIOB->ODR  = (GPIOB->ODR & (~(0b1111111<<3)));   // PB3~PB9
		  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, 1);          // GND pin for digit unit, count1
		  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_11, 1);         // GND pin for digit tens, count1
		  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 1);          // GND pin for digit unit, count2
		  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 1);          // GND pin for digit tens, count2
		 // turn off timer for led7seg
		  __HAL_RCC_TIM4_CLK_DISABLE();
	  }
	  if ((gTime.Hours == 5) && (gTime.Minutes == 0) )  {  // daytime mode from 05:00
		  daytime = 1;
		  __HAL_RCC_TIM4_CLK_ENABLE();
		  HAL_TIM_Base_Start_IT(&htim4);
	  }

	  if (daytime == 1) {
		  proceedLight(&lightStat);
	  }

	  if (daytime == 0) {
		  toggleYellowLight();  // in night time we don't proceed lights, but toggle yellow light only
	  }

	  HAL_Delay(1000);	  // each loop: delay 1 second & update lightStatus & proceed lights
	  lightStat.countdown --; // reduce 1 second from time remaining
	  if (lightStat.countdown == 0)  {  // when count down reach 0, lightStatus changes

		  // when count down come to zero, lightColor change to new color;
		  if (lightStat.lightColor == lightGreen) lightStat.lightColor = lightYellow;
		  else lightStat.lightColor = lightGreen; // if it was yellow and count down reach 0, variable lightStat will record green light for new direction

		  //  if lights become yellow, no change in moving direction, count down 3 seconds yellow light
		  if (lightStat.lightColor == lightYellow) {
			  lightStat.countdown = yellowCountdown;
		  }

		  // if it was yellow light that has just finished, direction changes => in new direction: light = green, count down =max for green light
		  if (lightStat.lightColor == lightGreen) {

		      // direction change;
			  if (lightStat.direction == direction1) lightStat.direction = direction2;
			  else lightStat.direction = direction1;

			  lightStat.countdown = maxCountdown;
		  }
	  }

  }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

  return 0;
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC;
  PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief RTC Initialization Function
  * @param None
  * @retval None
  */
static void MX_RTC_Init(void)
{

  /* USER CODE BEGIN RTC_Init 0 */

  /* USER CODE END RTC_Init 0 */

  RTC_TimeTypeDef sTime = {0};
  RTC_DateTypeDef DateToUpdate = {0};

  /* USER CODE BEGIN RTC_Init 1 */

  /* USER CODE END RTC_Init 1 */
  /** Initialize RTC Only
  */
  hrtc.Instance = RTC;
  hrtc.Init.AsynchPrediv = RTC_AUTO_1_SECOND;
  hrtc.Init.OutPut = RTC_OUTPUTSOURCE_ALARM;
  if (HAL_RTC_Init(&hrtc) != HAL_OK)
  {
    Error_Handler();
  }

  /* USER CODE BEGIN Check_RTC_BKUP */

  /* USER CODE END Check_RTC_BKUP */

  /** Initialize RTC and set the Time and Date
  */
  sTime.Hours = 0x22;
  sTime.Minutes = 0x59;
  sTime.Seconds = 0x00;

  if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BCD) != HAL_OK)
  {
    Error_Handler();
  }
  DateToUpdate.WeekDay = RTC_WEEKDAY_MONDAY;
  DateToUpdate.Month = RTC_MONTH_JANUARY;
  DateToUpdate.Date = 0x1;
  DateToUpdate.Year = 0x22;

  if (HAL_RTC_SetDate(&hrtc, &DateToUpdate, RTC_FORMAT_BCD) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RTC_Init 2 */

  /* USER CODE END RTC_Init 2 */

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 8000;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 10;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7
                          |GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11
                          |GPIO_PIN_12|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_10|GPIO_PIN_11
                          |GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15
                          |GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6
                          |GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pins : PC13 PC14 PC15 */
  GPIO_InitStruct.Pin = GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA0 PA1 PA2 PA3
                           PA4 PA5 PA6 PA7
                           PA8 PA9 PA10 PA11
                           PA12 PA15 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7
                          |GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11
                          |GPIO_PIN_12|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB1 PB10 PB11
                           PB12 PB13 PB14 PB15
                           PB3 PB4 PB5 PB6
                           PB7 PB8 PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_10|GPIO_PIN_11
                          |GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15
                          |GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6
                          |GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

